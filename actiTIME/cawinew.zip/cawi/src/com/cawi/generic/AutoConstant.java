package com.cawi.generic;

public interface AutoConstant
{
	
	String chrome_key ="webdriver.chrome.driver";
	String gecko_key="webdriver.gecko.driver";
	String gecko_value="./drivers/geckodriver.exe";
	String chrome_value="./drivers/chromedriver.exe";
	String File_Path="./data/input.xlsx";
}
